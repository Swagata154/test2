    <?php

    if (!defined('ABSPATH')) exit;

    class AIDiviGenerator
    {
        const SELECTED_PLATFORM = 'selected_platform';
        const OPT_KEY = 'google_gemini_api_key';
        const OPEN_AI_KEY = 'open_ai_api_key';
        const OPT_MODEL = 'google_gemini_model_name';
        const OPEN_AI_MODEL = 'open_ai_model';

        public function __construct()
        {
            add_action('admin_menu', [$this, 'menu']);
            add_action('admin_init', [$this, 'register_settings']);
            add_action('wp_ajax_ai_divi_generate', [$this, 'ajax_generate_page']);
            add_action('wp_ajax_ai_divi_get_page_backups', [$this, 'getPageBackups']);
            add_action('wp_ajax_ai_divi_restore_specific_backup', [$this, 'ai_divi_restore_specific_backup']);
        }


        public function register_settings()
        {
            register_setting('ai_divi_group', self::SELECTED_PLATFORM);
            register_setting('ai_divi_group', self::OPT_KEY);
            register_setting('ai_divi_group', self::OPEN_AI_KEY);
            register_setting('ai_divi_group', self::OPT_MODEL);
            register_setting('ai_divi_group', self::OPEN_AI_MODEL);
        }


        public function menu()
        {
            add_menu_page('AI → Divi', 'AI → Divi', 'edit_pages', 'ai-divi', [$this, 'screen'], 'dashicons-art', 58);
        }

        private function prompt_template($type = 'page_creation_by_design', $brief = '', $existingCode = '', $title = '', $slug = '', $canModifyCapability = false, $ai_divi_specific_module = '', $ai_divi_module_preset_id = '')
        {
            $brief = empty($brief)
                ? "Create a new section and append after the existing code."
                : $brief;

            $moduleDescriptionRule = '';
            if (!empty($ai_divi_specific_module) && !empty($ai_divi_module_preset_id)) {
                $presetID = addslashes($ai_divi_module_preset_id);

                $moduleDescriptionRule =
                    "- Apply the preset ONLY to the \"$ai_divi_specific_module\" module in the section specified by the user.\n" .
                    "- Strictly use the preset ID ($presetID) as the module's `_module_preset` attribute. Example: [{$ai_divi_specific_module} _module_preset=\"$presetID\"]...[/{$ai_divi_specific_module}].\n" .
                    "- DO NOT add, change, or override any styles; use the preset exactly as provided.\n" .
                    "- Ignore the design for this module; do not try to match colors, spacing, or fonts.\n" .
                    "- DO NOT apply this preset to any other module.\n" .
                    "- All other modules without a preset should match the design exactly and maintain pixel-perfect accuracy.";
            } else if (!empty($ai_divi_specific_module)) {
                $moduleDescriptionRule = "
                - Generate the given design or user brief with \"$ai_divi_specific_module\" Module.
                - Match exactly as designed. 100% pixel-perfect for all modules.";
            } else {
                $moduleDescriptionRule = '- Match exactly as designed. 100% pixel-perfect for all modules.';
            }


            $skeleton = [
                'page_creation_by_design' => "You are a WordPress Divi layout reconstruction agent.
                    You will receive a design image (JPG, PNG, JPEG) representing a page layout.
                    Your task is to generate or modify Divi shortcodes based on the user instructions.

                    STRICT Instructions for generate code:
                    - Treat every instruction as new. Ignore all previous requests and forget the old conversation. Each instruction should be treated independently, with no reference to prior instructions or responses.
                    - Treat every instruction as a completely new, isolated request.
                    - Add new sections, modules, or elements after existing content unless the user gives exact placement instructions.
                    - If no explicit modification instruction is provided, ALWAYS create the new design as a NEW section.
                    - Even if the uploaded design looks similar to an existing section (hero, banner, etc), never modify or replace that section unless explicitly instructed and allowed.
                    - If a title or slug is provided, use them exactly in the AI output.
                    - If the title or slug is blank, use the brief as the title and generate a slug automatically based on that title.
                    - Maintain Divi structure: [et_pb_section], [et_pb_row], [et_pb_column], [et_pb_text], [et_pb_image], [et_pb_button], etc.
                    - Use inline CSS only if needed.
                    - Output valid JSON only, no markdown or extra text.   
                    
                    EXISTING CODE HANDLING RULES:
                    1. existing_code applies ONLY to the CURRENT request.
                    2. You MUST NOT remember or reuse existing code from earlier requests.
                    3. If existing_code is NOT provided or is empty:
                    - Produce ONLY NEW code.
                    - Do NOT output or recreate any previous layout.
                    4. If existing_code IS provided:
                    - Append new sections AFTER existing_code.
                    - Modify it ONLY if the user gives explicit modification instructions.
                    5. NEVER reconstruct, merge, or re-add any code from previous responses unless the user provides that code again in the CURRENT INPUT.
                    
                    $moduleDescriptionRule

                

                    Image Handling Instruction:
                    - For every image you detect in the provided design, use a placeholder image instead of the actual image.
                    - Generate placeholder URLs from https://placehold.co/.(eg: https://placehold.co/600x400)
                    - If can_modify_existing_code is 'No', never alter existing_code code; always create new, independent code and add with existing_code and give response as layout.
                    - Follow the brief strictly as followed: ' . $brief . '

                    Schema:
                    {
                        \"title\": string,
                        \"slug\": string,
                        \"layout\": string
                    }

                    Input:
                    {
                        \"image_url\": \"https://example.com/design.jpg\",
                        \"brief\": \"$brief\"  ,
                        \"existing_code\": \"$existingCode\",
                        \"title\": \"" . (!empty($title) ? $title : 'GENERATE_TITLE_FROM_BRIEF') . "\",
                        \"slug\": \"" . (!empty($slug) ? $slug : 'GENERATE_SLUG_FROM_TITLE') . "\",
                        \"can_modify_existing_code\": " . ($canModifyCapability ? 'Yes' : 'No') . "
                    }

                    The output must be:
                    {
                        \"title\": \"" . (!empty($title) ? $title : 'GENERATE_TITLE_FROM_BRIEF') . "\",
                        \"slug\": \"" . (!empty($slug) ? $slug : 'GENERATE_SLUG_FROM_TITLE') . "\",
                        \"layout\": \"[et_pb_section ...]...[/et_pb_section]\"
                    }

                    Start processing now:"
            ];

            return $skeleton[$type];
        }

        public function screen()
        {
            if (!current_user_can('edit_pages')) return;
    ?>
            <div class="wrap">
                <h1>AI → Divi Page Generator</h1>
                <form id="ai-divi-form" method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field('ai_divi_gen'); ?>
                    <table class="form-table">
                        <tr>
                            <th>Select Type</th>
                            <td>
                                <select name="ai_divi_page_type" id="ai_divi_page_type">
                                    <option value="page_creation_by_design" selected>Page</option>
                                    <option value="layout_creation_by_design">Layout</option>
                                </select>
                            </td>
                        </tr>
                        <tr class="page_creation_by_design show_by_type">
                            <th>Select Existing Page</th>
                            <td>
                                <div style="display: flex; gap: 12px;">
                                    <select name="ai_divi_specific_page" class="form-control">
                                        <option value="">-- Select a page to modify (optional) --</option>
                                        <?php
                                        $pages = get_pages(['post_status' => ['publish', 'draft'], 'sort_column' => 'post_title', 'sort_order' => 'ASC']);
                                        foreach ($pages as $page) {
                                            echo '<option value="' . esc_attr($page->ID) . '">' . esc_html($page->post_title) . ' - ' . ($page->post_name) . '</option>';
                                        }
                                        ?>
                                    </select>
                                    <a href="#TB_inline?width=600&height=400&inlineId=aiBackupModal"
                                        class="thickbox button button-secondary" id="viewBackup" style="display: none;">
                                        View Backup
                                    </a>
                                    <input type="hidden" id="ai_divi_nonce" value="<?php echo wp_create_nonce('ai_divi_nonce'); ?>">
                                </div>
                                <p class="description">Optional: Select a page to modify; leave empty to create a new page.</p>
                            </td>
                        </tr>
                        <tr class="layout_creation_by_design show_by_type" style="display: none;">
                            <th>Select Layout</th>
                            <td>
                                <?php
                                $layouts = $this->ai_divi_get_all_theme_builder_layouts();
                                echo '<select name="ai_divi_layout_id" id="ai_divi_layout" class="regular-text">';
                                foreach ($layouts as $layout) {
                                    echo '<option value="' . esc_attr($layout['id']) . '">'
                                        . esc_html($layout['title']) . ' (ID: ' . intval($layout['id']) . ')'
                                        . '</option>';
                                }
                                echo '</select>';
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Page Title (Optional)</th>
                            <td><input type="text" name="ai_divi_title" class="regular-text" placeholder="Page title (optional)"></td>
                        </tr>

                        <tr>
                            <th>Page Slug (Optional)</th>
                            <td><input type="text" name="ai_divi_slug" class="regular-text" placeholder="Page slug (optional)"></td>
                        </tr>

                        <tr>
                            <th>Design Image (Upload or URL)</th>
                            <td>
                                <div style="display: flex;">
                                    <div>
                                        <input type="file" name="design_image_file" accept="image/*" style="display:block; margin-bottom:10px;">
                                        <input type="url" name="design_image_url" class="regular-text" placeholder="Or enter design image URL">
                                        <p class="description">
                                            For the best results, upload a small, compressed image of a single section.
                                        </p>
                                    </div>
                                    <div>
                                        <button type="button" class="button button-secondary" id="clearBtn">Clear</button>
                                    </div>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th>Choose Any Specific Module(s)</th>
                            <td>
                                <select name="ai_divi_specific_module" id="ai_divi_specific_modules" class="regular-text select">
                                    <option value="">-- Select Module --</option>
                                    <optgroup label="Basic Modules">
                                        <option value="et_pb_text">Text</option>
                                        <option value="et_pb_blurb">Blurb</option>
                                        <option value="et_pb_button">Button</option>
                                        <option value="et_pb_image">Image</option>
                                        <option value="et_pb_code">Code</option>
                                        <option value="et_pb_video">Video</option>
                                        <option value="et_pb_audio">Audio</option>
                                        <option value="et_pb_divider">Divider / Spacer</option>
                                        <option value="et_pb_cta">Call To Action</option>
                                    </optgroup>

                                    <optgroup label="Layout Modules">
                                        <option value="et_pb_section">Section</option>
                                        <option value="et_pb_row">Row</option>
                                        <option value="et_pb_column">Column</option>
                                        <option value="et_pb_slider">Slider</option>
                                        <option value="et_pb_slide">Slide</option>
                                        <option value="et_pb_fullwidth_header">Fullwidth Header</option>
                                        <option value="et_pb_fullwidth_slider">Fullwidth Slider</option>
                                        <option value="et_pb_fullwidth_image">Fullwidth Image</option>
                                    </optgroup>

                                    <optgroup label="Content Modules">
                                        <option value="et_pb_gallery">Gallery</option>
                                        <option value="et_pb_portfolio">Portfolio</option>
                                        <option value="et_pb_filterable_portfolio">Filterable Portfolio</option>
                                        <option value="et_pb_blog">Blog</option>
                                        <option value="et_pb_post_slider">Post Slider</option>
                                        <option value="et_pb_post_title">Post Title</option>
                                        <option value="et_pb_post_content">Post Content</option>
                                        <option value="et_pb_shop">Shop</option>
                                        <option value="et_pb_search">Search</option>
                                        <option value="et_pb_pricing_tables">Pricing Tables</option>
                                        <option value="et_pb_pricing_table">Pricing Table Item</option>
                                    </optgroup>

                                    <optgroup label="Advanced Modules">
                                        <option value="et_pb_accordion">Accordion</option>
                                        <option value="et_pb_toggle">Toggle</option>
                                        <option value="et_pb_tabs">Tabs</option>
                                        <option value="et_pb_tab">Tab</option>
                                        <option value="et_pb_testimonial">Testimonial</option>
                                        <option value="et_pb_social_media_follow">Social Media Follow</option>
                                        <option value="et_pb_social_media_follow_network">Social Media Icon</option>
                                        <option value="et_pb_countdown_timer">Countdown Timer</option>
                                        <option value="et_pb_map">Map</option>
                                        <option value="et_pb_map_pin">Map Pin</option>
                                    </optgroup>

                                    <optgroup label="Contact Modules">
                                        <option value="et_pb_contact_form">Contact Form</option>
                                        <option value="et_pb_contact_field">Contact Field</option>
                                        <option value="et_pb_email_optin">Email Opt-in</option>
                                    </optgroup>

                                    <optgroup label="Fullwidth Modules">
                                        <option value="et_pb_fullwidth_menu">Fullwidth Menu</option>
                                        <option value="et_pb_fullwidth_code">Fullwidth Code</option>
                                        <option value="et_pb_fullwidth_map">Fullwidth Map</option>
                                    </optgroup>

                                    <optgroup label="WooCommerce Modules">
                                        <option value="et_pb_wc_images">Woo Images</option>
                                        <option value="et_pb_wc_title">Woo Title</option>
                                        <option value="et_pb_wc_price">Woo Price</option>
                                        <option value="et_pb_wc_add_to_cart">Woo Add To Cart</option>
                                        <option value="et_pb_wc_rating">Woo Rating</option>
                                        <option value="et_pb_wc_stock">Woo Stock</option>
                                        <option value="et_pb_wc_meta">Woo Meta</option>
                                        <option value="et_pb_wc_description">Woo Description</option>
                                        <option value="et_pb_wc_tabs">Woo Tabs</option>
                                        <option value="et_pb_wc_related">Woo Related Products</option>
                                        <option value="et_pb_wc_upsell">Woo Upsell</option>
                                        <option value="et_pb_wc_gallery">Woo Gallery</option>
                                    </optgroup>

                                    <optgroup label="Divi Supreme Modules">
                                        <option value="ds_before_after_image_slider">Supreme Before/After Slider</option>
                                        <option value="ds_gradient_text">Supreme Gradient Text</option>
                                        <option value="ds_flipbox">Supreme Flip Box</option>
                                        <option value="ds_facebook_feed">Supreme Facebook Feed</option>
                                        <option value="ds_instagram_feed">Supreme Instagram Feed</option>
                                        <option value="ds_social_share">Supreme Social Share</option>
                                        <option value="ds_image_hover">Supreme Image Hover</option>
                                        <option value="ds_dual_button">Supreme Dual Button</option>
                                        <option value="ds_typing_effect">Supreme Typing Effect</option>
                                        <option value="ds_business_hours">Supreme Business Hours</option>
                                        <option value="ds_contact_info">Supreme Contact Info</option>
                                        <option value="ds_icon_list">Supreme Icon List</option>
                                        <option value="ds_text_rotator">Supreme Text Rotator</option>
                                        <option value="ds_masonry_gallery">Supreme Masonry Gallery</option>
                                        <option value="ds_lottie">Supreme Lottie</option>
                                        <option value="ds_carousel">Supreme Carousel</option>
                                        <option value="ds_post_carousel">Supreme Post Carousel</option>
                                        <option value="ds_image_carousel">Supreme Image Carousel</option>
                                        <option value="ds_shape_divider">Supreme Shape Divider</option>
                                        <option value="ds_icon_box">Supreme Icon Box</option>
                                        <option value="ds_floating_multi_images">Supreme Floating Multi Images</option>
                                        <option value="ds_blog_grid">Supreme Blog Grid</option>
                                        <option value="ds_blog_carousel">Supreme Blog Carousel</option>
                                    </optgroup>
                                </select>
                            </td>
                        </tr>
                        <tr class="module_persets_wrapepr" style="display: none;">
                            <th>Choose Selected Module's Preset</th>
                            <td>
                                <select name="ai_divi_module_presets" id="ai_divi_module_presets" class="regular-text">
                                </select>
                                <p class="description">
                                    After selecting the preset, explicitly tell the AI, using the brief text box, in which section you want the module to appear.<br>
                                    For example: Create the cards using the Blurb Module and apply the given preset id.<br>
                                    Create the hero section heading as a Text Module and apply the given preset id.<br>
                                    Create the given design with "Blurb" Module and use the given preset id.
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="ai_divi_brief">Your Brief / Instructions</label></th>
                            <td><textarea name="ai_divi_brief" rows="8" class="large-text" placeholder="Build a new section that follows the supplied design."></textarea></td>
                        </tr>
                    </table>
                    <div class="page_creation_by_design show_by_type">
                        <input type="checkbox" name="divi_ai_can_modify_code" value="1" id="divi_ai_can_modify_code" class="form-control">
                        <label for="divi_ai_can_modify_code">
                            Allow AI to modify existing sections
                        </label>
                        <p class="description">
                            Check this box if you want the AI to have permission to view & modify existing sections. Leave it unchecked to ensure the AI always creates a new section without altering any existing content.
                        </p>
                    </div>
                    <div style="margin-bottom: 20px;">
                    </div>
                    <button type="submit" class="button button-primary">Generate / Modify Page</button>
                </form>
                <div id="ai-divi-response" style="margin-top:20px;"></div>
            </div>

            <div id="aiBackupModal" style="display:none;">
                <h2>Saved Backup</h2>
                <div id="backupResponse"></div>
                <div id="backupContent">Loading backup...</div>
            </div>

            <?php
            $builder_global_presets = get_option('et_divi');
            ?>

            <script>
                jQuery(document).ready(function($) {
                    $('#ai-divi-form').on('submit', function(e) {
                        e.preventDefault();

                        var formData = new FormData(this);
                        formData.append('action', 'ai_divi_generate');

                        var $resp = $('#ai-divi-response');
                        var done = false;

                        $resp.html('<div class="notice notice-info"><p>Thinking...</p></div>');

                        var thinkingTimer = setTimeout(function() {
                            if (!done) {
                                $resp.html('<div class="notice notice-info"><p>Generating...</p></div>');
                            }
                        }, 30000);

                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: formData,
                            contentType: false,
                            processData: false,
                            success: function(response) {
                                done = true;
                                clearTimeout(thinkingTimer);

                                if (response.success) {
                                    $resp.html('<div class="notice notice-success"><p>' + response.data.message + '</p></div>');
                                } else {
                                    $resp.html('<div class="notice notice-error"><p>' + response.data.message + '</p></div>');
                                }
                            },
                            error: function(err) {
                                done = true;
                                clearTimeout(thinkingTimer);

                                $resp.html('<div class="notice notice-error"><p>AJAX error. See console.</p></div>');
                                console.log(err);
                            }
                        });
                    });

                    $('#ai_divi_page_type').on('change', show_by_type);

                    function show_by_type() {
                        $('.show_by_type').css('display', 'none');
                        $(`.${$('#ai_divi_page_type').val()}`).css('display', 'table-row');
                    }

                    show_by_type();

                    $('#clearBtn').on('click', function() {
                        $('input[name="design_image_url"]').val('');
                        $('input[name="design_image_file"]').val('');
                    });

                    $('select[name="ai_divi_specific_page"]').on('change', function() {
                        if ($(this).val() == '') {
                            $('#viewBackup').css({
                                'display': 'none'
                            });
                        } else {
                            $('#viewBackup').css({
                                'display': ''
                            });
                        }
                    });

                    $('#viewBackup').on('click', function() {

                        let data = {
                            "page_id": $('select[name="ai_divi_specific_page"]').val(),
                            "action": "ai_divi_get_page_backups",
                            "nonce": $('#ai_divi_nonce').val()
                        };
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: data,
                            dataType: 'json',
                            success: function(res) {
                                if (res.success) {
                                    $('#backupContent').html(res.data.html);
                                }
                            },
                            beforeSend: function() {
                                $('#backupContent').html('Loading backup...');
                                $('#backupResponse').html('');
                            }
                        });
                    });

                    $(document).on('click', '.ai-divi-restore-backup', function() {
                        let content = $(this).data('content');
                        let pageId = $(this).data('page_id');
                        let nonce = $('#ai_divi_nonce').val();
                        let btn = $(this);
                        btn.html('...');
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: "ai_divi_restore_specific_backup",
                                page_id: pageId,
                                content: content,
                                nonce: nonce
                            },
                            success: function(res) {
                                if (res.success) {
                                    $('#backupResponse').html('<div class="notice notice-success" style="margin: 0px; margin-bottom: 20px;"><p>' + res.data.html + '</p></div>');
                                } else {
                                    $('#backupResponse').html('<div class="notice notice-error" style="margin: 0px; margin-bottom: 20px;"><p>' + res.data + '</p></div>');
                                }
                            },
                            beforeSend: function() {
                                $('#backupResponse').html('');
                            },
                            complete: function() {
                                btn.html('Restore');
                            }
                        });

                    });


                    var builderPresets = <?php echo json_encode($builder_global_presets); ?>;

                    $('#ai_divi_specific_modules').on('change', function() {
                        var selectedModule = this.value;
                        var $presetDropdown = $('#ai_divi_module_presets');
                        $presetDropdown.empty();
                        $presetDropdown.append('<option value="">Default Preset</option>');

                        if (!selectedModule) {
                            $('.module_persets_wrapepr').css('display', 'none');
                        } else {
                            $('.module_persets_wrapepr').css('display', '');
                        }

                        var modulePresetsObj = builderPresets.builder_global_presets[selectedModule];
                        if (!modulePresetsObj || !modulePresetsObj.presets) {
                            return;
                        }

                        var presets = modulePresetsObj.presets;
                        for (var presetId in presets) {
                            if (presets.hasOwnProperty(presetId)) {
                                var presetName = presets[presetId].name || presetId;
                                $presetDropdown.append(
                                    '<option value="' + presetId + '">' + presetName + '</option>'
                                );
                            }
                        }
                    });

                    $('#ai_divi_module_presets').on('change', function() {
                        var selectedModule = $('#ai_divi_specific_modules').val();
                        var selectedPresetId = this.value;

                        if (!selectedModule || !selectedPresetId) return;

                        var presetSettings = builderPresets.builder_global_presets[selectedModule].presets[selectedPresetId].settings;
                        console.log('Settings for selected preset:', presetSettings);
                    });
                });
            </script>
    <?php
        }

        function ai_divi_restore_specific_backup()
        {
            if (!wp_verify_nonce($_POST['nonce'], 'ai_divi_nonce')) {
                wp_send_json_error("Invalid nonce!");
            }

            $page_id = intval($_POST['page_id']);
            $content = stripslashes($_POST['content']);

            if (!$page_id || empty($content)) {
                wp_send_json_error("Missing page_id or content!");
            }

            $updated = wp_update_post([
                'ID'           => $page_id,
                'post_content' => wp_slash($content)
            ]);

            if (is_wp_error($updated)) {
                wp_send_json_error("Failed to restore backup!");
            }

            $url = get_permalink($page_id);

            wp_send_json_success([
                'html' => '<strong>Backup restored successfully!</strong> <a href="' . $url . '" target="_blank">View page</a>',
            ]);
        }

        public function getPageBackups()
        {
            global $wpdb;
            check_ajax_referer('ai_divi_nonce', 'nonce');

            if (empty($_POST['page_id'])) {
                wp_send_json_error(['message' => 'Missing page_id']);
            }
            $page_id = absint($_POST['page_id']);

            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT meta_value 
            FROM $wpdb->postmeta 
            WHERE post_id = %d 
            AND meta_key = '_ai_divi_backup_page_content'
            ORDER BY meta_id DESC",
                    $page_id
                ),
                ARRAY_A
            );
            if (empty($rows)) {
                wp_send_json_success([
                    'html' => '<p>No backups found for this page.</p>'
                ]);
            }
            $html = '<table class="widefat striped">
                    <thead>
                        <tr>
                            <th width="10%">SL No.</th>
                            <th width="70%">Backup Time</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>';
            foreach ($rows as $index => $row) {
                $metaValue = $row['meta_value'];
                $separator = '~~##$$%%^^TIME';

                $pos = strrpos($metaValue, $separator);

                if ($pos === false) {
                    $content = $metaValue;
                    $time = '';
                } else {
                    $content = substr($metaValue, 0, $pos);
                    $time    = substr($metaValue, $pos + strlen($separator));
                }
                $showDateTime = date("jS M, Y \a\\t h:i A", strtotime($time));
                $html .= '
                <tr>
                    <td>' . ($index + 1) . '</td>
                    <td>' . $showDateTime . '</td>
                    <td>
                        <button 
                            class="button button-primary ai-divi-restore-backup" 
                            data-content="' . esc_attr($content) . '" data-page_id="' . $page_id . '">
                            Restore
                        </button>
                    </td>
                </tr>';
            }
            $html .= '</tbody></table>';
            wp_send_json_success([
                'html' => $html
            ]);
        }

        /**
         * Safely replaces a Divi module/section matching the identifier.
         * Supports: section, row, column, or any module with attribute or text match.
         *
         * @param string $old_content   Existing Divi content.
         * @param string $new_section   New shortcode section to insert.
         * @param string $identifier    Search keyword (module name, title, id etc.)
         * @return string Updated Divi content or original if not found.
         */
        function ai_divi_safe_section_replace($old_content, $new_section, $identifier)
        {

            if (empty($old_content) || empty($identifier)) {
                return $old_content;
            }

            $identifier = trim($identifier);

            // Normalize whitespace for reliable matching
            $clean_old = preg_replace('/\s+/', ' ', $old_content);

            // Regex pattern to match entire Divi block (section/row/module)
            $pattern = '/(\[et_pb_[a-zA-Z0-9_]+.*?\])(.*?)(\[\/et_pb_[a-zA-Z0-9_]+\])/si';

            preg_match_all($pattern, $old_content, $matches, PREG_OFFSET_CAPTURE);

            if (empty($matches[0])) {
                return $old_content;
            }

            $updated = $old_content;
            $found = false;

            foreach ($matches[0] as $match) {

                $full_block = $match[0];

                // Check if the identifier appears in:
                // - shortcode attributes
                // - inner text
                if (
                    stripos($full_block, $identifier) !== false ||
                    preg_match('/' . preg_quote($identifier, '/') . '/i', $full_block)
                ) {

                    $found = true;

                    // Replace target block with new one
                    $updated = str_replace($full_block, "\n" . $new_section . "\n", $updated);

                    break; // Stop after first match (keeps performance)
                }
            }

            return $found ? $updated : $old_content;
        }


        public function getPresetCode($ai_divi_module_presets, $ai_divi_specific_module)
        {
            $builder_global_presets = maybe_unserialize(get_option('et_divi'));

            if ($ai_divi_specific_module && $ai_divi_module_presets) {
                return $builder_global_presets['builder_global_presets']?->$ai_divi_specific_module?->presets?->$ai_divi_module_presets ?? '';
            }

            return '';
        }

        public function ajax_generate_page()
        {
            check_ajax_referer('ai_divi_gen');

            $api_key = get_option(self::OPT_KEY, '');
            $gemini_model = get_option(self::OPT_MODEL, 'gemini-2.5-flash');

            $selected_platform = get_option(self::SELECTED_PLATFORM, 'gemini');

            $open_ai_key = get_option(self::OPEN_AI_KEY, '');
            $open_ai_model = get_option(self::OPEN_AI_MODEL, 'gpt-5');


            // $api_key = get_option(self::OPT_KEY, 'AIzaSyBfnQvS2K56zL7kRI8Z8ROwbt4mlk7afRg');
            if (!$api_key) {
                wp_send_json_error(['message' => 'Add your Google Gemini API key first from "AI → Divi Tools > Tools" page.']);
            }

            $brief   = sanitize_textarea_field($_POST['ai_divi_brief'] ?? '');
            $image_url = esc_url_raw($_POST['design_image_url'] ?? '');
            $specificPage = intval($_POST['ai_divi_specific_page'] ?? '');
            $existingCode = '';
            $title = sanitize_text_field($_POST['ai_divi_title'] ?? '');
            $slug  = sanitize_title($_POST['ai_divi_slug'] ?? '');
            $type = sanitize_title($_POST['ai_divi_page_type'] ?? '');
            $ai_divi_layout_id = sanitize_title($_POST['ai_divi_layout_id'] ?? '');
            $divi_ai_can_modify_code = empty($_POST['divi_ai_can_modify_code']) ? 0 : 1;
            $ai_divi_module_presets = $_POST['ai_divi_module_presets'] ?? '';
            $ai_divi_specific_module = $_POST['ai_divi_specific_module'] ?? '';
            // $presetStyles = $this->getPresetCode($ai_divi_module_presets, $ai_divi_specific_module);


            if ($type == 'page_creation_by_design') {
                if ($specificPage) {
                    $page = get_post($specificPage);
                    if ($page && $page->post_type === 'page') {
                        $existingCode = $page->post_content;
                        if (empty($title)) $title = $page->post_title;
                        if (empty($slug)) $slug = $page->post_name;
                    }
                }
            } else if ($type == 'layout_creation_by_design') {
                if ($ai_divi_layout_id) {
                    $existingCode  = $this->ai_divi_get_layout_content_by_id($ai_divi_layout_id);
                } else {
                    wp_send_json_error(['message' => 'Please select a layout.']);
                }
            } else {
                wp_send_json_error(['message' => 'Please select a type.']);
            }
            $generator = $this;
            $prompt = $generator->prompt_template('page_creation_by_design', $brief, $existingCode, $title, $slug, $divi_ai_can_modify_code == 1, $ai_divi_specific_module, $ai_divi_module_presets);

            $parts = [['text' => $prompt]];

            if (!empty($_FILES['design_image_file']['tmp_name']) && $_FILES['design_image_file']['error'] === UPLOAD_ERR_OK) {
                $uploaded_file = $_FILES['design_image_file']['tmp_name'];
                $mime_type = mime_content_type($uploaded_file);
                $parts[] = ['inline_data' => ['mime_type' => $mime_type, 'data' => base64_encode(file_get_contents($uploaded_file))]];
            } elseif (!empty($image_url)) {
                $image_contents = @file_get_contents($image_url);
                if ($image_contents !== false) {
                    $finfo = new finfo(FILEINFO_MIME_TYPE);
                    $mime_type = $finfo->buffer($image_contents);
                    $parts[] = ['inline_data' => ['mime_type' => $mime_type, 'data' => base64_encode($image_contents)]];
                }
            }

            error_reporting(E_ALL);

            if ($selected_platform == 'gemini') {
                $raw = $this->getResponseByGemini($parts, $api_key, $gemini_model);
            } else if ($selected_platform == 'open_ai') {
                $raw = $this->getResponseByOpenAI($parts, $open_ai_key, $open_ai_model);
            } else {
                wp_send_json_error(['message' => 'Please select a platform from "AI → Divi" → "Tools"']);
            }

            if (($raw['success'] ?? 0) != 1) {
                wp_send_json_error(['message' => $raw['msg'] ?? "Something went wrong."]);
            }
            $json =  ai_clean_json($raw['data']);
            if (!$json || empty($json['layout'])) {
                $errMsg = 'AI output not valid JSON. Output: ' . $raw;
                if (empty($raw)) {
                    if (!empty($body['error'])) {
                        $errMsg = $body['error']['message'];
                    } else {
                        $errMsg = 'Something went wrong. Please try again.';
                    }
                }
                wp_send_json_error(['message' => $errMsg]);
            }

            $page_title = !empty($title) ? $title : sanitize_text_field($json['title'] ?? 'AI Divi Page');
            $page_slug  = !empty($slug) ? $slug : sanitize_title($json['slug'] ?? $page_title);
            $layout     = wp_kses_post($json['layout']);

            if (strpos($layout, '[et_pb_section') === false) {
                wp_send_json_error(['message' => 'Generated content does not contain Divi shortcodes.']);
            }

            if ($type == 'page_creation_by_design') {
                if ($specificPage) {
                    $page = get_post($specificPage);
                    $post_status = $page && isset($page->post_status)
                        ? $page->post_status
                        : 'draft';

                    if (!empty($divi_ai_can_modify_code) && !empty($ai_divi_specific_module)) {

                        $identifier = sanitize_title($ai_divi_specific_module);

                        // Replace section matching the identifier only (keep full shortcode structure)
                        $updatedContent = $this->ai_divi_safe_section_replace($existingCode, $layout, $identifier);

                        if (!$updatedContent || $updatedContent === $existingCode) {
                            // If nothing matched → append instead (safe fallback)
                            $updatedContent = $existingCode . "\n\n" . $layout;
                        }

                        $layout = $updatedContent;
                    } else {
                        $layout = $layout;
                    }

                    if (!empty($existingCode)) {
                        $saveContent = $existingCode . '~~##$$%%^^TIME' . current_time('mysql');
                        add_post_meta(
                            $specificPage,
                            '_ai_divi_backup_page_content',
                            $saveContent,
                            false
                        );
                    }

                    $post_id = wp_update_post([
                        'ID'           => $specificPage,
                        'post_title'   => $page_title,
                        'post_name'    => $page_slug,
                        'post_content' => $layout,
                        'post_status'  => $post_status
                    ], true);
                } else {
                    $existing_page = get_page_by_path($page_slug, OBJECT, 'page');
                    if ($existing_page) {
                        wp_send_json_error(['message' => 'This slug is already present can not create another please choose the page from above dropdown to modify the page.']);
                    } else {
                        $post_id = wp_insert_post([
                            'post_title'   => $page_title,
                            'post_name'    => $page_slug,
                            'post_content' => $layout,
                            'post_status'  => 'draft',
                            'post_type'    => 'page'
                        ], true);
                    }
                }
                // Always enable Divi builder
                if (!is_wp_error($post_id)) {
                    update_post_meta($post_id, '_et_pb_use_builder', 'on');
                    update_post_meta($post_id, 'et_pb_use_builder', 'on');
                }
                if (function_exists('et_core_cache_flush')) et_core_cache_flush();
                wp_cache_flush();

                $edit_link = admin_url('post.php?action=edit&post=' . (int)$post_id);

                if (get_post_status($post_id) === 'publish') {
                    $view_link = get_permalink($post_id);
                } else {
                    $view_link = add_query_arg(
                        [
                            'preview' => 'true',
                        ],
                        get_permalink($post_id)
                    );
                }

                $message  = 'Page saved successfully.<br>';
                $message .= '<a href="' . esc_url($edit_link) . '" target="_blank">🛠 Open in Divi Builder</a> | ';
                $message .= '<a href="' . esc_url($view_link) . '" target="_blank">👁 View Page</a>';

                wp_send_json_success(['message' => $message]);
            } else if ($type == 'layout_creation_by_design') {
                $res = $this->ai_divi_update_layout_by_id($ai_divi_layout_id, $layout);
                if ($res['status'] == 0) {
                    wp_send_json_error(['message' => $res['msg']]);
                } else {
                    wp_send_json_success(['message' => $res['msg']]);
                }
            } else {
                wp_send_json_error(['message' => 'Please select a type.']);
            }
            wp_send_json_error(['message' => 'Something Went wrong.']);
        }

        public function getResponseByGemini(array $inputParts, string $key, string $model)
        {
            $payload = ['contents' => [['parts' => $inputParts]]];
            $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent';
            $resp = wp_remote_post($endpoint, [
                'headers' => ['Content-Type' => 'application/json', 'x-goog-api-key' => $key],
                'body' => wp_json_encode($payload),
                'timeout' => 6000
            ]);

            if (is_wp_error($resp)) {
                wp_send_json_error(['message' => $resp->get_error_message()]);
            }

            $body = json_decode(wp_remote_retrieve_body($resp), true);
            $raw = trim($body['candidates'][0]['content']['parts'][0]['text'] ?? '');

            if (!empty($raw)) {
                return ['success' => 1, 'data' => $raw];
            }
            if (!empty($body['error'])) {
                $errMsg = '<strong>GEMINI:</strong> ' . $body['error']['message'];
            } else {
                $errMsg = 'Something went wrong. Please try again.';
            }
            return ['success' => 0, 'msg' => $errMsg];
        }

        public function getResponseByOpenAI(array $parts, string $open_ai_key, string $open_ai_model)
        {
            if (empty($parts)) {
                return '';
            }

            $messages = [];
            foreach ($parts as $part) {
                $messages[] = [
                    'role' => 'user',
                    'content' => $part
                ];
            }

            $payload = [
                'model' => $open_ai_model,
                'messages' => $messages,
                'temperature' => 0.7,
                'max_tokens' => 1000
            ];

            $endpoint = 'https://api.openai.com/v1/chat/completions';

            $resp = wp_remote_post($endpoint, [
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Bearer ' . $open_ai_key
                ],
                'body' => wp_json_encode($payload),
                'timeout' => 60
            ]);

            if (is_wp_error($resp)) {
                wp_send_json_error(['message' => $resp->get_error_message()]);
            }

            $body = json_decode(wp_remote_retrieve_body($resp), true);

            $raw = '';
            if (!empty($body['choices'][0]['message']['content'])) {
                $raw = trim($body['choices'][0]['message']['content']);
            }

            if (!empty($raw)) {
                return ['success' => 1, 'data' => $raw];
            }
            if (!empty($body['error'])) {
                $errMsg = '<strong>OPEN AI:</strong> ' . $body['error']['message'];
            } else {
                $errMsg = 'Something went wrong. Please try again.';
            }
            return ['success' => 0, 'msg' => $errMsg];
        }

        public function ai_divi_get_all_theme_builder_layouts()
        {
            $results = [];

            $templates = get_posts([
                'post_type'      => 'et_template',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'orderby'        => 'modified',
                'order'          => 'DESC',
            ]);

            if (empty($templates)) {
                return [];
            }

            $unique_templates = [];

            foreach ($templates as $template) {
                $template_title = trim($template->post_title);

                // Skip invalid or duplicate template names
                if (empty($template_title) || strtolower($template_title) === 'all templates') {
                    continue;
                }
                if (isset($unique_templates[$template_title])) {
                    continue;
                }

                // Divi theme builder meta keys
                $header_id = get_post_meta($template->ID, '_et_header_layout_id', true);
                $footer_id = get_post_meta($template->ID, '_et_footer_layout_id', true);
                $body_id   = get_post_meta($template->ID, '_et_body_layout_id', true);

                // Skip templates that don't have any valid layouts
                if (!$header_id && !$footer_id && !$body_id) {
                    continue;
                }

                $unique_templates[$template_title] = [
                    'template_id' => $template->ID,
                    'title'       => $template_title,
                    'header_id'   => $header_id,
                    'footer_id'   => $footer_id,
                    'body_id'     => $body_id,
                ];
            }

            // Build final list (header, footer, and now body)
            foreach ($unique_templates as $t) {

                if ($t['header_id']) {
                    $results[] = [
                        'id'          => intval($t['header_id']),
                        'title'       => 'Header - ' . $t['title'],
                        'template_id' => intval($t['template_id']),
                        'part'        => 'header',
                    ];
                }

                if ($t['body_id']) {
                    $results[] = [
                        'id'          => intval($t['body_id']),
                        'title'       => 'Body - ' . $t['title'],
                        'template_id' => intval($t['template_id']),
                        'part'        => 'body',
                    ];
                }

                if ($t['footer_id']) {
                    $results[] = [
                        'id'          => intval($t['footer_id']),
                        'title'       => 'Footer - ' . $t['title'],
                        'template_id' => intval($t['template_id']),
                        'part'        => 'footer',
                    ];
                }
            }

            return $results;
        }

        public function ai_divi_get_layout_content_by_id($layout_id)
        {
            $layout_post = get_post($layout_id);
            return $layout_post->post_content ?? '--';
        }

        public function saveToFile($new_content)
        {
            if (! function_exists('WP_Filesystem')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }

            WP_Filesystem();

            global $wp_filesystem;

            $file_path = ABSPATH . 'my-layout-data.json';

            if (is_array($new_content)) {
                $new_content = json_encode($new_content, JSON_PRETTY_PRINT);
            }

            $wp_filesystem->put_contents(
                $file_path,
                $new_content,
                FS_CHMOD_FILE
            );

            return "File saved at: " . $file_path;
        }

        public function ai_divi_update_layout_by_id($layout_id, $new_content)
        {
            if (empty($layout_id) || empty($new_content)) return ['status' => 0, 'msg' => 'Layout ID or content is empty.'];
            $layout_post = get_post($layout_id);

            if (!$layout_post || ($layout_post->post_type !== 'et_header_layout' && $layout_post->post_type !== 'et_footer_layout' && $layout_post->post_type !== 'et_body_layout')) {
                return ['status' => 0, 'msg' => 'Invalid layout ID.'];
            }

            $update = wp_update_post([
                'ID'           => $layout_id,
                'post_content' => wp_kses_post($new_content),
                'post_status'  => 'publish',
            ], true);

            if (is_wp_error($update)) {
                return ['status' => 0, 'msg' => 'Error updating layout: ' . $update->get_error_message()];
            }

            // Clear Divi builder cache to ensure immediate visibility
            if (function_exists('et_pb_clear_global_css_cache')) {
                et_pb_clear_global_css_cache();
            }
            return ['status' => 1, 'msg' => 'Layout updated successfully.'];
        }

        public function ai_divi_create_new_layout($layout_content, $layout_type = 'et_header_layout')
        {
            if (empty($layout_content)) {
                return false;
            }

            // Create new layout
            $new_layout_id = wp_insert_post([
                'post_title'   => 'AI Generated Layout ' . wp_date('Y-m-d H:i:s'),
                'post_content' => wp_kses_post($layout_content),
                'post_status'  => 'publish',
                'post_type'    => $layout_type, // 'et_header_layout' or 'et_footer_layout'
            ]);

            if (is_wp_error($new_layout_id)) {
                return false;
            }

            // Clear Divi cache
            if (function_exists('et_pb_clear_global_css_cache')) {
                et_pb_clear_global_css_cache();
            }

            return $new_layout_id;
        }
    }

    new AIDiviGenerator();
