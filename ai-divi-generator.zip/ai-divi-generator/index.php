<?php

/**
 * Plugin Name: AI → Divi Page Generator
 * Description: Generate or modify Divi pages dynamically from natural-language brief and provided design using Google Gemini API and OPEN AI (AJAX ready).
 * Version: 1.0.2
 * Author: Web Programmer
 */

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'ai-divi-generator-page.php';
require_once plugin_dir_path(__FILE__) . 'ai-divi-generator-section.php';

class AIDiviPluginBootstrap
{
    private $generator;
    private $tools;

    public function __construct()
    {
        // $this->generator = new AIDiviGenerator();
        $this->tools = new AIDiviTools();
    }
}

new AIDiviPluginBootstrap();


function dd(...$args)
{
    echo '<pre>';
    foreach ($args as $arg) {
        print_r($arg);
    }
}
function ddx(...$args)
{
    dd($args);
    exit;
}

function ai_clean_json($text)
{
    $text = preg_replace('/[\x00-\x1F\x7F\xA0\xAD\x{200B}-\x{200F}\x{FEFF}]/u', '', $text);
    $text = preg_replace('/^```json\s*/i', '', $text);
    $text = preg_replace('/^```\s*/', '', $text);
    $text = preg_replace('/\s*```$/', '', $text);
    $text = str_replace('```', '', $text);
    return json_decode(trim($text), true);
}

function enqueue_thickbox_scripts()
{
    add_thickbox();
}
add_action('admin_enqueue_scripts', 'enqueue_thickbox_scripts');


/** NOTES FROM DINESH 
 *  - Provide optimized image and small image for a single section only at a time.
 *  - If want any specific thing like do with a specific module then give that in brief.
 *  - After giving the brief use chat GPT and ask for better optimized prompt to get better result.
 *  - Chech the allow AI checkbox when you need AI to made some changes in your existing page like change the section sequences, add the given design after 3rd section
 *  - Tell AI that in which section you want the specific modification and th esection name you can identify by it's first heading or a text. eg: change the "Our team" section with purple background.
 *  - The backup page content is saved in postmeta table with _ai_divi_backup_page_content meta key
 *  ENJOY VIBE CODING :)
 */
